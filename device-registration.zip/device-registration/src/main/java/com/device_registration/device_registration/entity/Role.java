package com.device_registration.device_registration.entity;

public enum Role {
    USER,
    ADMIN
}
