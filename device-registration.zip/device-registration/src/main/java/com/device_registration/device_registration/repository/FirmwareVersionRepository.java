package com.device_registration.device_registration.repository;

import com.device_registration.device_registration.entity.FirmwareVersion;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface FirmwareVersionRepository extends JpaRepository<FirmwareVersion, Long> {

    Optional<FirmwareVersion> findByVersion(String version);

    boolean existsByVersion(String version);

    List<FirmwareVersion> findByVersionContainingIgnoreCase(String version);

}
