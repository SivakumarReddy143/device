package com.device_registration.device_registration.config;

import com.device_registration.device_registration.entity.Role;
import com.device_registration.device_registration.entity.User;
import com.device_registration.device_registration.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.*;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
@RequiredArgsConstructor
public class DataInitializer {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Bean
    public CommandLineRunner initAdmin() {
        return args -> {

            String adminEmail = "puneeth@gmail.com";

            // ✅ Check if admin already exists
            if (!userRepository.existsByEmail(adminEmail)) {

                User admin = User.builder()
                        .username("puneeth")
                        .email(adminEmail)
                        .password(passwordEncoder.encode("Puneeth@123")) // encrypted
                        .role(Role.ADMIN)
                        .build();

                userRepository.save(admin);

                System.out.println("✅ Admin account created successfully");
            } else {
                System.out.println("ℹ️ Admin already exists");
            }
        };
    }
}