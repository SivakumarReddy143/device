package com.device_registration.device_registration.repository;

import com.device_registration.device_registration.entity.Device;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DeviceRepository extends JpaRepository<Device, Long> {

    List<Device> findByStatus(String status);

    List<Device> findByFirmwareIsNull();

    List<Device> findByFirmwareIdNot(Long firmwareId);

    List<Device> findByNameContainingIgnoreCase(String name);

}
