package com.device_registration.device_registration.dto;

import lombok.Data;

@Data
public class RefreshRequest {
    private String refreshToken;
}
