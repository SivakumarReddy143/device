package com.device_registration.device_registration.dto;

import lombok.Data;

@Data
public class LoginRequest {
    private String email;
    private String password;
}
