package com.device_registration.device_registration.repository;

import com.device_registration.device_registration.entity.RefreshToken;
import com.device_registration.device_registration.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface RefreshTokenRepository extends JpaRepository<RefreshToken, Long> {

    Optional<RefreshToken> findByToken(String token);

    void deleteByUser(User user);
}
