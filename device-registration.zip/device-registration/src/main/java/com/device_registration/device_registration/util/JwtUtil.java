package com.device_registration.device_registration.util;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.util.Date;

@Component
public class JwtUtil {

    // 🔐 Minimum 32 characters (256-bit) for HS256
    private static final String SECRET =
            "my-super-secure-secret-key-which-is-at-least-32-characters";

    // Generate signing key
    private SecretKey getSigningKey() {
        return Keys.hmacShaKeyFor(SECRET.getBytes());
    }

    // 🔑 Generate JWT Token
    public String generateToken(String email) {
        return Jwts.builder()
                .setSubject(email) // unique identifier
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + 1000 * 60 * 15)) // 15 minutes
                .signWith(getSigningKey(), SignatureAlgorithm.HS256)
                .compact();
    }

    // 📥 Extract Email (subject)
    public String extractUsername(String token) {
        return extractAllClaims(token).getSubject();
    }

    // ⏳ Check if token expired
    public boolean isTokenExpired(String token) {
        return extractAllClaims(token).getExpiration().before(new Date());
    }

    // ✅ Validate Token
    public boolean isTokenValid(String token) {
        return !isTokenExpired(token);
    }

    // 🔍 Extract all claims
    private Claims extractAllClaims(String token) {
        return Jwts.parserBuilder()
                .setSigningKey(getSigningKey())
                .build()
                .parseClaimsJws(token)
                .getBody();
    }
}