package com.device_registration.device_registration.service;


import com.device_registration.device_registration.dto.DeviceRequestDTO;
import com.device_registration.device_registration.dto.DeviceResponseDTO;
import com.device_registration.device_registration.entity.ChangeLog;
import com.device_registration.device_registration.entity.Device;
import com.device_registration.device_registration.entity.FirmwareVersion;
import com.device_registration.device_registration.exception.ResourceNotFoundException;
import com.device_registration.device_registration.exception.BadRequestException;
import com.device_registration.device_registration.repository.ChangeLogRepository;
import com.device_registration.device_registration.repository.DeviceRepository;
import com.device_registration.device_registration.repository.FirmwareVersionRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DeviceService {

    private final DeviceRepository deviceRepository;
    private final FirmwareVersionRepository firmwareRepository;
    private final ChangeLogRepository changeLogRepository;

    public DeviceService(DeviceRepository deviceRepository,
                         FirmwareVersionRepository firmwareRepository,
                         ChangeLogRepository changeLogRepository) {
        this.deviceRepository = deviceRepository;
        this.firmwareRepository = firmwareRepository;
        this.changeLogRepository = changeLogRepository;
    }

    public DeviceResponseDTO createDevice(DeviceRequestDTO dto) {
        Device device = new Device();
        device.setName(dto.getName());
        device.setStatus(dto.getStatus());

        if (dto.getFirmwareId() != null) {
            FirmwareVersion firmware = firmwareRepository.findById(dto.getFirmwareId())
                    .orElseThrow(() -> new ResourceNotFoundException(
                            "Firmware not found with id: " + dto.getFirmwareId()
                    ));
            device.setFirmware(firmware);
        }

        Device saved = deviceRepository.save(device);

        addChangeLog(saved, "Device created with status: " + saved.getStatus());

        return mapToResponse(saved);
    }

    public List<DeviceResponseDTO> getAllDevices() {
        return deviceRepository.findAll()
                .stream()
                .map(this::mapToResponse)
                .toList();
    }

    public DeviceResponseDTO getDeviceById(Long id) {
        Device device = getDeviceEntityById(id);
        return mapToResponse(device);
    }

    public DeviceResponseDTO updateDevice(Long id, DeviceRequestDTO dto) {
        Device device = getDeviceEntityById(id);

        String oldStatus = device.getStatus();
        String oldFirmware = getFirmwareVersionText(device);

        device.setName(dto.getName());
        device.setStatus(dto.getStatus());

        if (dto.getFirmwareId() != null) {
            FirmwareVersion firmware = firmwareRepository.findById(dto.getFirmwareId())
                    .orElseThrow(() -> new ResourceNotFoundException(
                            "Firmware not found with id: " + dto.getFirmwareId()
                    ));
            device.setFirmware(firmware);
        } else {
            device.setFirmware(null);
        }

        Device updated = deviceRepository.save(device);

        String newFirmware = getFirmwareVersionText(updated);

        if (!oldStatus.equals(updated.getStatus())) {
            addChangeLog(updated, "Device status changed from " + oldStatus + " to " + updated.getStatus());
        }

        if (!oldFirmware.equals(newFirmware)) {
            addChangeLog(updated, "Firmware changed from " + oldFirmware + " to " + newFirmware);
        }

        return mapToResponse(updated);
    }

    public DeviceResponseDTO updateDeviceStatus(Long id, String status) {
        if (!status.equals("ACTIVE") && !status.equals("INACTIVE")) {
            throw new BadRequestException("Status must be ACTIVE or INACTIVE");
        }

        Device device = getDeviceEntityById(id);

        String oldStatus = device.getStatus();

        if (oldStatus.equals(status)) {
            return mapToResponse(device);
        }

        device.setStatus(status);
        Device updated = deviceRepository.save(device);

        addChangeLog(updated, "Device status changed from " + oldStatus + " to " + status);

        return mapToResponse(updated);
    }

    public DeviceResponseDTO updateDeviceFirmware(Long id, Long firmwareId) {
        Device device = getDeviceEntityById(id);

        FirmwareVersion firmware = firmwareRepository.findById(firmwareId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Firmware not found with id: " + firmwareId
                ));

        String oldFirmware = getFirmwareVersionText(device);

        device.setFirmware(firmware);
        Device updated = deviceRepository.save(device);

        addChangeLog(updated, "Firmware changed from " + oldFirmware + " to " + firmware.getVersion());

        return mapToResponse(updated);
    }

    public void deleteDevice(Long id) {
        Device device = getDeviceEntityById(id);

        changeLogRepository.deleteByDeviceId(id);

        deviceRepository.delete(device);
    }

    public List<DeviceResponseDTO> getDevicesByStatus(String status) {
        if (!status.equals("ACTIVE") && !status.equals("INACTIVE")) {
            throw new BadRequestException("Status must be ACTIVE or INACTIVE");
        }

        return deviceRepository.findByStatus(status)
                .stream()
                .map(this::mapToResponse)
                .toList();
    }

    public List<DeviceResponseDTO> getDevicesMissingFirmware() {
        return deviceRepository.findByFirmwareIsNull()
                .stream()
                .map(this::mapToResponse)
                .toList();
    }

    public List<DeviceResponseDTO> getDevicesOnOutdatedFirmware(Long latestFirmwareId) {
        firmwareRepository.findById(latestFirmwareId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Firmware not found with id: " + latestFirmwareId
                ));

        return deviceRepository.findByFirmwareIdNot(latestFirmwareId)
                .stream()
                .map(this::mapToResponse)
                .toList();
    }

    private void addChangeLog(Device device, String action) {
        ChangeLog log = new ChangeLog();
        log.setDevice(device);
        log.setAction(action);
        changeLogRepository.save(log);
    }

    private Device getDeviceEntityById(Long id) {
        return deviceRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Device not found with id: " + id
                ));
    }

    private String getFirmwareVersionText(Device device) {
        return device.getFirmware() != null
                ? device.getFirmware().getVersion()
                : "NONE";
    }

    private DeviceResponseDTO mapToResponse(Device device) {
        Long firmwareId = null;
        String firmwareVersion = null;

        if (device.getFirmware() != null) {
            firmwareId = device.getFirmware().getId();
            firmwareVersion = device.getFirmware().getVersion();
        }

        return new DeviceResponseDTO(
                device.getId(),
                device.getName(),
                device.getStatus(),
                firmwareId,
                firmwareVersion,
                device.getCreatedAt(),
                device.getUpdatedAt()
        );
    }
    public Page<DeviceResponseDTO> getAllDevicesPaged(Pageable pageable) {
        return deviceRepository.findAll(pageable)
                .map(this::mapToResponse);
    }
    public List<DeviceResponseDTO> searchDevicesByName(String name) {
        return deviceRepository.findByNameContainingIgnoreCase(name)
                .stream()
                .map(this::mapToResponse)
                .toList();
    }

}