package com.device_registration.device_registration.controller;

import com.device_registration.device_registration.dto.AuthResponse;
import com.device_registration.device_registration.dto.LoginRequest;
import com.device_registration.device_registration.dto.RefreshRequest;
import com.device_registration.device_registration.dto.RegisterRequest;
import com.device_registration.device_registration.entity.RefreshToken;
import com.device_registration.device_registration.entity.User;
import com.device_registration.device_registration.repository.RefreshTokenRepository;
import com.device_registration.device_registration.service.AuthService;
import com.device_registration.device_registration.service.RefreshTokenService;
import com.device_registration.device_registration.util.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;
    private final RefreshTokenService refreshTokenService;
    private final RefreshTokenRepository refreshTokenRepository;
    private final JwtUtil jwtUtil;

    @PostMapping("/register")
    public String register(@RequestBody RegisterRequest request) {
        return authService.register(request);
    }
    @PostMapping("/login")
    public AuthResponse login(@RequestBody LoginRequest request) {
        return authService.login(request);
    }
    @PostMapping("/refresh")
    public AuthResponse refresh(@RequestBody RefreshRequest request) {

        RefreshToken refreshToken = refreshTokenRepository.findByToken(request.getRefreshToken())
                .orElseThrow(() -> new RuntimeException("Invalid refresh token"));

        refreshTokenService.verifyExpiration(refreshToken);

        User user = refreshToken.getUser();

        String newAccessToken = jwtUtil.generateToken(user.getEmail());

        return new AuthResponse(newAccessToken, refreshToken.getToken());
    }

    @PostMapping("/logout")
    public String logout(@RequestBody RefreshRequest request) {

        RefreshToken token = refreshTokenRepository.findByToken(request.getRefreshToken())
                .orElseThrow(() -> new RuntimeException("Token not found"));

        refreshTokenRepository.delete(token);

        return "Logged out successfully";
    }
}
