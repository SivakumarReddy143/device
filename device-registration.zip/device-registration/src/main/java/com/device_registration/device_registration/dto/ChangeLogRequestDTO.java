package com.device_registration.device_registration.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class ChangeLogRequestDTO {

    @NotNull(message = "Device ID is required")
    private Long deviceId;

    @NotBlank(message = "Action is required")
    @Size(min = 3, max = 255, message = "Action must be between 3 and 255 characters")
    private String action;

    public ChangeLogRequestDTO() {
    }

    public Long getDeviceId() {
        return deviceId;
    }

    public String getAction() {
        return action;
    }

    public void setDeviceId(Long deviceId) {
        this.deviceId = deviceId;
    }

    public void setAction(String action) {
        this.action = action;
    }
}