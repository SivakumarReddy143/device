package com.device_registration.device_registration.controller;

import com.device_registration.device_registration.dto.ChangeLogRequestDTO;
import com.device_registration.device_registration.dto.ChangeLogResponseDTO;
import com.device_registration.device_registration.service.ChangeLogService;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/changelogs")
public class ChangeLogController {

    private final ChangeLogService changeLogService;

    public ChangeLogController(ChangeLogService changeLogService) {
        this.changeLogService = changeLogService;
    }

    @PostMapping
    public ResponseEntity<ChangeLogResponseDTO> createChangeLog(
            @Valid @RequestBody ChangeLogRequestDTO dto
    ) {
        return new ResponseEntity<>(changeLogService.createChangeLog(dto), HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<ChangeLogResponseDTO>> getAllChangeLogs() {
        return ResponseEntity.ok(changeLogService.getAllChangeLogs());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ChangeLogResponseDTO> getChangeLogById(@PathVariable Long id) {
        return ResponseEntity.ok(changeLogService.getChangeLogById(id));
    }

    @GetMapping("/device/{deviceId}")
    public ResponseEntity<List<ChangeLogResponseDTO>> getChangeLogsByDeviceId(
            @PathVariable Long deviceId
    ) {
        return ResponseEntity.ok(changeLogService.getChangeLogsByDeviceId(deviceId));
    }

    @GetMapping("/device/{deviceId}/latest")
    public ResponseEntity<ChangeLogResponseDTO> getLatestChangeLogByDeviceId(
            @PathVariable Long deviceId
    ) {
        return ResponseEntity.ok(changeLogService.getLatestChangeLogByDeviceId(deviceId));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteChangeLog(@PathVariable Long id) {
        changeLogService.deleteChangeLog(id);
        return ResponseEntity.ok("Change log deleted successfully");
    }
    @GetMapping("/paged")
    public ResponseEntity<Page<ChangeLogResponseDTO>> getAllChangeLogsPaged(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "5") int size,
            @RequestParam(defaultValue = "id") String sortBy,
            @RequestParam(defaultValue = "desc") String direction
    ) {
        Sort sort = direction.equalsIgnoreCase("desc")
                ? Sort.by(sortBy).descending()
                : Sort.by(sortBy).ascending();

        Pageable pageable = PageRequest.of(page, size, sort);

        return ResponseEntity.ok(changeLogService.getAllChangeLogsPaged(pageable));
    }
    @GetMapping("/search")
    public ResponseEntity<?> searchChangeLogsByAction(@RequestParam String action) {
        return ResponseEntity.ok(changeLogService.searchChangeLogsByAction(action));
    }


}
