package com.device_registration.device_registration.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class FirmwareRequestDTO {

    @NotBlank(message = "Firmware version is required")
    @Size(min = 3, max = 50, message = "Firmware version must be between 3 and 50 characters")
    private String version;

    @Size(max = 1000, message = "Notes cannot exceed 1000 characters")
    private String notes;

    public FirmwareRequestDTO() {
    }

    public String getVersion() {
        return version;
    }

    public String getNotes() {
        return notes;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }
}