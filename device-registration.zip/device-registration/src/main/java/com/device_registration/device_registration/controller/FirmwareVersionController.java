package com.device_registration.device_registration.controller;


import com.device_registration.device_registration.dto.FirmwareRequestDTO;
import com.device_registration.device_registration.dto.FirmwareResponseDTO;
import com.device_registration.device_registration.service.FirmwareVersionService;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/firmware")
public class FirmwareVersionController {

    private final FirmwareVersionService firmwareService;

    public FirmwareVersionController(FirmwareVersionService firmwareService) {
        this.firmwareService = firmwareService;
    }

    @PostMapping
    public ResponseEntity<FirmwareResponseDTO> createFirmware(
            @Valid @RequestBody FirmwareRequestDTO dto
    ) {
        return new ResponseEntity<>(firmwareService.createFirmware(dto), HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<FirmwareResponseDTO>> getAllFirmware() {
        return ResponseEntity.ok(firmwareService.getAllFirmware());
    }

    @GetMapping("/{id}")
    public ResponseEntity<FirmwareResponseDTO> getFirmwareById(@PathVariable Long id) {
        return ResponseEntity.ok(firmwareService.getFirmwareById(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<FirmwareResponseDTO> updateFirmware(
            @PathVariable Long id,
            @Valid @RequestBody FirmwareRequestDTO dto
    ) {
        return ResponseEntity.ok(firmwareService.updateFirmware(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteFirmware(@PathVariable Long id) {
        firmwareService.deleteFirmware(id);
        return ResponseEntity.ok("Firmware deleted successfully");
    }
    @GetMapping("/compare")
    public ResponseEntity<Integer> compareFirmwareVersions(
            @RequestParam String version1,
            @RequestParam String version2
    ) {
        return ResponseEntity.ok(firmwareService.compareSemVer(version1, version2));
    }
    @GetMapping("/paged")
    public ResponseEntity<Page<FirmwareResponseDTO>> getAllFirmwarePaged(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "5") int size,
            @RequestParam(defaultValue = "id") String sortBy,
            @RequestParam(defaultValue = "asc") String direction
    ) {
        Sort sort = direction.equalsIgnoreCase("desc")
                ? Sort.by(sortBy).descending()
                : Sort.by(sortBy).ascending();

        Pageable pageable = PageRequest.of(page, size, sort);

        return ResponseEntity.ok(firmwareService.getAllFirmwarePaged(pageable));
    }
    @GetMapping("/search")
    public ResponseEntity<?> searchFirmwareByVersion(@RequestParam String version) {
        return ResponseEntity.ok(firmwareService.searchFirmwareByVersion(version));
    }

}