package com.device_registration.device_registration.config;

import com.device_registration.device_registration.security.JwtFilter;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
@RequiredArgsConstructor
public class SecurityConfig {

    private final JwtFilter jwtFilter;

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .csrf(csrf -> csrf.disable())
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/auth/**").permitAll()

                        .requestMatchers(HttpMethod.POST, "/api/firmware").hasRole("ADMIN")

                        .requestMatchers(HttpMethod.PUT, "/api/firmware/**").hasRole("ADMIN")

                        .requestMatchers(HttpMethod.DELETE, "/api/firmware/**").hasRole("ADMIN")

                        .requestMatchers(HttpMethod.GET,
                                "/api/firmware",
                                "/api/firmware/**",
                                "/api/firmware/search",
                                "/api/firmware/paged",
                                "/api/firmware/compare"
                        ).hasAnyRole("USER", "ADMIN")

                        .requestMatchers(HttpMethod.POST, "/api/devices")
                        .hasRole("ADMIN")

                        .requestMatchers(HttpMethod.PUT, "/api/devices/**")
                        .hasRole("ADMIN")

                        .requestMatchers(HttpMethod.DELETE, "/api/devices/**")
                        .hasRole("ADMIN")

                        .requestMatchers(HttpMethod.PATCH,
                                "/api/devices/**/status",
                                "/api/devices/**/firmware/**"
                        ).hasRole("ADMIN")

                        .requestMatchers(HttpMethod.GET,
                                "/api/devices",
                                "/api/devices/**",
                                "/api/devices/status/**",
                                "/api/devices/missing-firmware",
                                "/api/devices/outdated-firmware/**",
                                "/api/devices/search",
                                "/api/devices/paged"
                        ).hasAnyRole("USER", "ADMIN")

                        .requestMatchers(HttpMethod.POST, "/api/changelogs")
                        .hasRole("ADMIN")

                        .requestMatchers(HttpMethod.DELETE, "/api/changelogs/**")
                        .hasRole("ADMIN")

                        .requestMatchers(HttpMethod.GET,
                                "/api/changelogs",
                                "/api/changelogs/**",
                                "/api/changelogs/device/**",
                                "/api/changelogs/device/**/latest",
                                "/api/changelogs/search",
                                "/api/changelogs/paged"
                        ).hasAnyRole("USER", "ADMIN")


                        .anyRequest().authenticated()
                )
                .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }
}
