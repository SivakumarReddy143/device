package com.device_registration.device_registration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeviceRegistrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
