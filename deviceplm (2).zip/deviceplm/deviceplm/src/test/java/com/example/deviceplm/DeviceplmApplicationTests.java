package com.example.deviceplm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeviceplmApplicationTests {

	@Test
	void contextLoads() {
	}

}
