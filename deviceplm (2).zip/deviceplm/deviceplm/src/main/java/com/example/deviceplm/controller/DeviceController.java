package com.example.deviceplm.controller;

import com.example.deviceplm.dto.DeviceRequestDTO;
import com.example.deviceplm.dto.DeviceResponseDTO;
import com.example.deviceplm.service.DeviceService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;


@RestController
@RequestMapping("/api/devices")
public class DeviceController {

    private final DeviceService deviceService;

    public DeviceController(DeviceService deviceService) {
        this.deviceService = deviceService;
    }

    @PostMapping
    public ResponseEntity<?> createDevice(@Valid @RequestBody DeviceRequestDTO dto) {
        return new ResponseEntity<>(deviceService.createDevice(dto), HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<?> getAllDevices() {
        return ResponseEntity.ok(deviceService.getAllDevices());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getDeviceById(@PathVariable Long id) {
        return ResponseEntity.ok(deviceService.getDeviceById(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateDevice(
            @PathVariable Long id,
            @Valid @RequestBody DeviceRequestDTO dto
    ) {
        return ResponseEntity.ok(deviceService.updateDevice(id, dto));
    }

    @PatchMapping("/{id}/status")
    public ResponseEntity<DeviceResponseDTO> updateDeviceStatus(
            @PathVariable Long id,
            @RequestParam String status
    ) {
        return ResponseEntity.ok(deviceService.updateDeviceStatus(id, status));
    }

    @PatchMapping("/{id}/firmware/{firmwareId}")
    public ResponseEntity<DeviceResponseDTO> updateDeviceFirmware(
            @PathVariable Long id,
            @PathVariable Long firmwareId
    ) {
        return ResponseEntity.ok(deviceService.updateDeviceFirmware(id, firmwareId));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteDevice(@PathVariable Long id) {
        deviceService.deleteDevice(id);
        return ResponseEntity.ok("Device deleted successfully");
    }

    @GetMapping("/status/{status}")
    public ResponseEntity<?> getDevicesByStatus(@PathVariable String status) {
        return ResponseEntity.ok(deviceService.getDevicesByStatus(status));
    }

    @GetMapping("/missing-firmware")
    public ResponseEntity<?> getDevicesMissingFirmware() {
        return ResponseEntity.ok(deviceService.getDevicesMissingFirmware());
    }

    @GetMapping("/outdated-firmware/{latestFirmwareId}")
    public ResponseEntity<?> getDevicesOnOutdatedFirmware(
            @PathVariable Long latestFirmwareId
    ) {
        return ResponseEntity.ok(deviceService.getDevicesOnOutdatedFirmware(latestFirmwareId));
    }
    @GetMapping("/paged")
    public ResponseEntity<Page<DeviceResponseDTO>> getAllDevicesPaged(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "5") int size,
            @RequestParam(defaultValue = "id") String sortBy,
            @RequestParam(defaultValue = "asc") String direction
    ) {
        Sort sort = direction.equalsIgnoreCase("desc")
                ? Sort.by(sortBy).descending()
                : Sort.by(sortBy).ascending();

        Pageable pageable = PageRequest.of(page, size, sort);

        return ResponseEntity.ok(deviceService.getAllDevicesPaged(pageable));
    }
    @GetMapping("/search")
    public ResponseEntity<?> searchDevicesByName(@RequestParam String name) {
        return ResponseEntity.ok(deviceService.searchDevicesByName(name));
    }


}
