package com.example.deviceplm.dto;

import java.time.LocalDateTime;

public class ChangeLogResponseDTO {

    private Long id;
    private Long deviceId;
    private String deviceName;
    private String action;
    private LocalDateTime timestamp;

    public ChangeLogResponseDTO() {
    }

    public ChangeLogResponseDTO(Long id, Long deviceId, String deviceName,
                                String action, LocalDateTime timestamp) {
        this.id = id;
        this.deviceId = deviceId;
        this.deviceName = deviceName;
        this.action = action;
        this.timestamp = timestamp;
    }

    public Long getId() {
        return id;
    }

    public Long getDeviceId() {
        return deviceId;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public String getAction() {
        return action;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setDeviceId(Long deviceId) {
        this.deviceId = deviceId;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }
}