package com.example.deviceplm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeviceplmApplication {

	public static void main(String[] args) {
		SpringApplication.run(DeviceplmApplication.class, args);
	}

}
