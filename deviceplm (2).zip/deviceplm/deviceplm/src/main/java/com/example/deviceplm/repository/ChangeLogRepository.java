package com.example.deviceplm.repository;

import com.example.deviceplm.model.ChangeLog;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ChangeLogRepository extends JpaRepository<ChangeLog, Long> {

    List<ChangeLog> findByDeviceId(Long deviceId);

    Optional<ChangeLog> findTopByDeviceIdOrderByTimestampDesc(Long deviceId);

    void deleteByDeviceId(Long deviceId);

    List<ChangeLog> findByActionContainingIgnoreCase(String action);

}
