package com.example.deviceplm.repository;

import com.example.deviceplm.model.FirmwareVersion;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface FirmwareVersionRepository extends JpaRepository<FirmwareVersion, Long> {

    Optional<FirmwareVersion> findByVersion(String version);

    boolean existsByVersion(String version);

    List<FirmwareVersion> findByVersionContainingIgnoreCase(String version);

}
