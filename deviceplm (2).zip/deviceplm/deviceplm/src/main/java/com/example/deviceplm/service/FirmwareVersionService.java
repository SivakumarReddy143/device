package com.example.deviceplm.service;

import com.example.deviceplm.dto.FirmwareRequestDTO;
import com.example.deviceplm.dto.FirmwareResponseDTO;
import com.example.deviceplm.exception.BadRequestException;
import com.example.deviceplm.exception.ResourceNotFoundException;
import com.example.deviceplm.model.FirmwareVersion;
import com.example.deviceplm.repository.FirmwareVersionRepository;
import org.springframework.stereotype.Service;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;


import java.util.List;

@Service
public class FirmwareVersionService {

    private final FirmwareVersionRepository firmwareRepository;

    public FirmwareVersionService(FirmwareVersionRepository firmwareRepository) {
        this.firmwareRepository = firmwareRepository;
    }

    public FirmwareResponseDTO createFirmware(FirmwareRequestDTO dto) {
        if (firmwareRepository.existsByVersion(dto.getVersion())) {
            throw new BadRequestException("Firmware version already exists: " + dto.getVersion());
        }

        FirmwareVersion firmware = new FirmwareVersion();
        firmware.setVersion(dto.getVersion());
        firmware.setNotes(dto.getNotes());

        FirmwareVersion saved = firmwareRepository.save(firmware);
        return mapToResponse(saved);
    }

    public List<FirmwareResponseDTO> getAllFirmware() {
        return firmwareRepository.findAll()
                .stream()
                .map(this::mapToResponse)
                .toList();
    }

    public FirmwareResponseDTO getFirmwareById(Long id) {
        FirmwareVersion firmware = firmwareRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Firmware not found with id: " + id));

        return mapToResponse(firmware);
    }

    public FirmwareResponseDTO updateFirmware(Long id, FirmwareRequestDTO dto) {
        FirmwareVersion firmware = firmwareRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Firmware not found with id: " + id));

        firmwareRepository.findByVersion(dto.getVersion()).ifPresent(existing -> {
            if (!existing.getId().equals(id)) {
                throw new BadRequestException("Firmware version already exists: " + dto.getVersion());
            }
        });

        firmware.setVersion(dto.getVersion());
        firmware.setNotes(dto.getNotes());

        FirmwareVersion updated = firmwareRepository.save(firmware);
        return mapToResponse(updated);
    }

    public void deleteFirmware(Long id) {
        FirmwareVersion firmware = firmwareRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Firmware not found with id: " + id));

        firmwareRepository.delete(firmware);
    }

    private FirmwareResponseDTO mapToResponse(FirmwareVersion firmware) {
        return new FirmwareResponseDTO(
                firmware.getId(),
                firmware.getVersion(),
                firmware.getNotes(),
                firmware.getCreatedAt()
        );
    }
    public int compareSemVer(String version1, String version2) {
        String[] v1Parts = version1.split("\\.");
        String[] v2Parts = version2.split("\\.");

        int length = Math.max(v1Parts.length, v2Parts.length);

        for (int i = 0; i < length; i++) {
            int v1 = i < v1Parts.length ? Integer.parseInt(v1Parts[i]) : 0;
            int v2 = i < v2Parts.length ? Integer.parseInt(v2Parts[i]) : 0;

            if (v1 < v2) {
                return -1;
            }

            if (v1 > v2) {
                return 1;
            }
        }

        return 0;
    }
    public Page<FirmwareResponseDTO> getAllFirmwarePaged(Pageable pageable) {
        return firmwareRepository.findAll(pageable)
                .map(this::mapToResponse);
    }
    public List<FirmwareResponseDTO> searchFirmwareByVersion(String version) {
        return firmwareRepository.findByVersionContainingIgnoreCase(version)
                .stream()
                .map(this::mapToResponse)
                .toList();
    }

}