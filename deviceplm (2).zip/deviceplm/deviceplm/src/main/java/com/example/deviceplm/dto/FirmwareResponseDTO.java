package com.example.deviceplm.dto;

import java.time.LocalDateTime;

public class FirmwareResponseDTO {

    private Long id;
    private String version;
    private String notes;
    private LocalDateTime createdAt;

    public FirmwareResponseDTO() {
    }

    public FirmwareResponseDTO(Long id, String version, String notes, LocalDateTime createdAt) {
        this.id = id;
        this.version = version;
        this.notes = notes;
        this.createdAt = createdAt;
    }

    public Long getId() {
        return id;
    }

    public String getVersion() {
        return version;
    }

    public String getNotes() {
        return notes;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}