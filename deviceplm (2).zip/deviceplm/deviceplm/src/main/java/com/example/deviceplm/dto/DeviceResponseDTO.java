package com.example.deviceplm.dto;

import java.time.LocalDateTime;

public class DeviceResponseDTO {

    private Long id;
    private String name;
    private String status;
    private Long firmwareId;
    private String firmwareVersion;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public DeviceResponseDTO() {
    }

    public DeviceResponseDTO(Long id, String name, String status,
                             Long firmwareId, String firmwareVersion,
                             LocalDateTime createdAt, LocalDateTime updatedAt) {
        this.id = id;
        this.name = name;
        this.status = status;
        this.firmwareId = firmwareId;
        this.firmwareVersion = firmwareVersion;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getStatus() {
        return status;
    }

    public Long getFirmwareId() {
        return firmwareId;
    }

    public String getFirmwareVersion() {
        return firmwareVersion;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setFirmwareId(Long firmwareId) {
        this.firmwareId = firmwareId;
    }

    public void setFirmwareVersion(String firmwareVersion) {
        this.firmwareVersion = firmwareVersion;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
}
