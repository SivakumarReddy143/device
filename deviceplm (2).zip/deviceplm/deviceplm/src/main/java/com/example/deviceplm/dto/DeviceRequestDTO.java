package com.example.deviceplm.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public class DeviceRequestDTO {

    @NotBlank(message = "Device name is required")
    @Size(min = 2, max = 100, message = "Device name must be between 2 and 100 characters")
    private String name;

    @NotBlank(message = "Status is required")
    @Pattern(regexp = "ACTIVE|INACTIVE", message = "Status must be ACTIVE or INACTIVE")
    private String status;

    private Long firmwareId;

    public DeviceRequestDTO() {
    }

    public String getName() {
        return name;
    }

    public String getStatus() {
        return status;
    }

    public Long getFirmwareId() {
        return firmwareId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setFirmwareId(Long firmwareId) {
        this.firmwareId = firmwareId;
    }
}