package com.example.deviceplm.service;

import com.example.deviceplm.dto.ChangeLogRequestDTO;
import com.example.deviceplm.dto.ChangeLogResponseDTO;
import com.example.deviceplm.exception.ResourceNotFoundException;
import com.example.deviceplm.model.ChangeLog;
import com.example.deviceplm.model.Device;
import com.example.deviceplm.repository.ChangeLogRepository;
import com.example.deviceplm.repository.DeviceRepository;
import org.springframework.stereotype.Service;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;


import java.util.List;

@Service
public class ChangeLogService {

    private final ChangeLogRepository changeLogRepository;
    private final DeviceRepository deviceRepository;

    public ChangeLogService(ChangeLogRepository changeLogRepository,
                            DeviceRepository deviceRepository) {
        this.changeLogRepository = changeLogRepository;
        this.deviceRepository = deviceRepository;
    }

    public ChangeLogResponseDTO createChangeLog(ChangeLogRequestDTO dto) {
        Device device = deviceRepository.findById(dto.getDeviceId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Device not found with id: " + dto.getDeviceId()
                ));

        ChangeLog changeLog = new ChangeLog();
        changeLog.setDevice(device);
        changeLog.setAction(dto.getAction());

        ChangeLog saved = changeLogRepository.save(changeLog);
        return mapToResponse(saved);
    }

    public List<ChangeLogResponseDTO> getAllChangeLogs() {
        return changeLogRepository.findAll()
                .stream()
                .map(this::mapToResponse)
                .toList();
    }

    public ChangeLogResponseDTO getChangeLogById(Long id) {
        ChangeLog changeLog = changeLogRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Change log not found with id: " + id
                ));

        return mapToResponse(changeLog);
    }

    public List<ChangeLogResponseDTO> getChangeLogsByDeviceId(Long deviceId) {
        if (!deviceRepository.existsById(deviceId)) {
            throw new ResourceNotFoundException("Device not found with id: " + deviceId);
        }

        return changeLogRepository.findByDeviceId(deviceId)
                .stream()
                .map(this::mapToResponse)
                .toList();
    }

    public ChangeLogResponseDTO getLatestChangeLogByDeviceId(Long deviceId) {
        if (!deviceRepository.existsById(deviceId)) {
            throw new ResourceNotFoundException("Device not found with id: " + deviceId);
        }

        ChangeLog changeLog = changeLogRepository
                .findTopByDeviceIdOrderByTimestampDesc(deviceId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "No change logs found for device id: " + deviceId
                ));

        return mapToResponse(changeLog);
    }

    public void deleteChangeLog(Long id) {
        ChangeLog changeLog = changeLogRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Change log not found with id: " + id
                ));

        changeLogRepository.delete(changeLog);
    }

    private ChangeLogResponseDTO mapToResponse(ChangeLog changeLog) {
        return new ChangeLogResponseDTO(
                changeLog.getId(),
                changeLog.getDevice().getId(),
                changeLog.getDevice().getName(),
                changeLog.getAction(),
                changeLog.getTimestamp()
        );
    }
    public Page<ChangeLogResponseDTO> getAllChangeLogsPaged(Pageable pageable) {
        return changeLogRepository.findAll(pageable)
                .map(this::mapToResponse);
    }
    public List<ChangeLogResponseDTO> searchChangeLogsByAction(String action) {
        return changeLogRepository.findByActionContainingIgnoreCase(action)
                .stream()
                .map(this::mapToResponse)
                .toList();
    }

}

