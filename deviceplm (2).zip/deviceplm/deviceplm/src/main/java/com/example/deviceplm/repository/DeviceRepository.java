package com.example.deviceplm.repository;

import com.example.deviceplm.model.Device;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DeviceRepository extends JpaRepository<Device, Long> {

    List<Device> findByStatus(String status);

    List<Device> findByFirmwareIsNull();

    List<Device> findByFirmwareIdNot(Long firmwareId);

    List<Device> findByNameContainingIgnoreCase(String name);

}
