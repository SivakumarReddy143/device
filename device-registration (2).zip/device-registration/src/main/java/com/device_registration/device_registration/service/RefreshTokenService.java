package com.device_registration.device_registration.service;

import com.device_registration.device_registration.entity.RefreshToken;
import com.device_registration.device_registration.entity.User;
import com.device_registration.device_registration.repository.RefreshTokenRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Optional;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Transactional
public class RefreshTokenService {

    private final RefreshTokenRepository refreshTokenRepository;

    // 7 days
    private final long REFRESH_TOKEN_DURATION =
            7 * 24 * 60 * 60 * 1000;

    public RefreshToken createRefreshToken(User user) {

        // Delete old refresh token
        refreshTokenRepository.deleteByUser(user);

        // Force immediate execution of delete query
        refreshTokenRepository.flush();

        // Create new refresh token
        RefreshToken refreshToken = RefreshToken.builder()
                .user(user)
                .token(UUID.randomUUID().toString())
                .expiryDate(
                        Instant.now()
                                .plusMillis(REFRESH_TOKEN_DURATION)
                )
                .build();

        return refreshTokenRepository.save(refreshToken);
    }

    public Optional<RefreshToken> findByToken(String token) {
        return refreshTokenRepository.findByToken(token);
    }

    public RefreshToken verifyExpiration(RefreshToken token) {

        if (token.getExpiryDate().isBefore(Instant.now())) {

            refreshTokenRepository.delete(token);

            refreshTokenRepository.flush();

            throw new RuntimeException(
                    "Refresh token expired. Please login again."
            );
        }

        return token;
    }

    public void deleteByUser(User user) {

        refreshTokenRepository.deleteByUser(user);

        refreshTokenRepository.flush();
    }
}